import java.io.*;

import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.Number;

public class WriteExcel {
	
	/*private String value;
	
    public String getValue() {
		return value;
	}
    
	public void setValue(String value) {
		this.value = value;
	}*/

	/*private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat times;
    private String inputFile;

    public void setOutputFile(String inputFile) {
    	this.inputFile = inputFile;
    }

    public void write() throws IOException, WriteException {
        File file = new File(inputFile);
        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        WritableWorkbook workbook = Workbook.createWorkbook(file, wbSettings);
        workbook.createSheet("Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);
//        createLabel(excelSheet);
//        createContent(excelSheet);

        workbook.write();
        workbook.close();
    }
    */
	public void write(String fileName,int curCol,int curRow,String value,CellType ct) throws IOException, WriteException, BiffException{
		Workbook existingWorkbook = Workbook.getWorkbook(new File(fileName));
		WritableWorkbook workbookCopy = Workbook.createWorkbook(new File(fileName), existingWorkbook);
		WritableSheet sheetToEdit = workbookCopy.getSheet("Sheet1");
		WritableCell cell=null;
		if(ct == CellType.LABEL){
			Label l = new Label(curCol, curRow, value);
			cell = (WritableCell) l;
			sheetToEdit.addCell(cell);
		}
		if(ct == CellType.NUMBER){
			//Label l = new Label(curCol, curRow, value);
			//cell = (WritableCell) l;
			int l = Integer.parseInt(value);
			sheetToEdit.addCell(new Number(curCol,curRow,l));
		}
		 workbookCopy.write();
		 workbookCopy.close();
		 existingWorkbook.close();
	}
}