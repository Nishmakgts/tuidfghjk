public class Account {

	protected long accountNumber;
	protected float accountBalance;
	protected String accountName;
	protected String phoneNumber;
	protected String branch = "Bangalore";
	protected String address;
	protected String password;

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public long getAccountNumber() {
		return this.accountNumber;
	}

	public float getAccountBalance() {
		return this.accountBalance;
	}

	public String getAccountName() {
		return this.accountName;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public String getBranch() {
		return this.branch;
	}

	public String getAddress() {
		return this.address;
	}
	public String getPassword() {
		return password;
	}
	
	public void deposit(float deposit) {
		this.accountBalance = this.accountBalance + deposit;
	}

	public void withdrawl(float withdrawl) {
		this.accountBalance = this.accountBalance - withdrawl;
	}
	
	public Account transfer(float transferAmount,Account benAcc){
		this.withdrawl(transferAmount);
		benAcc.deposit(transferAmount);
		return benAcc;
	}
}