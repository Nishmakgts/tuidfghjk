import java.io.*;
import jxl.*;
import jxl.read.biff.BiffException;

public class OpenAccount extends Account{
	
	private String identificatonNumber;
	
	public void setIdentificationNumber(String idnum){
		this.identificatonNumber = idnum;
	}
	
	public String getIdentificationNumber(){
		return this.identificatonNumber;
	}
	
	public OpenAccount(String name,String ph,String address,String idnum){
		setAccountName(name);
		setPhoneNumber(ph);
		setAddress(address);
		setIdentificationNumber(idnum);
	}
	
	public int getSheetRows(String fileName) throws BiffException, IOException{
		ReadExcelFile ex = new ReadExcelFile();
		Sheet sh = ex.readExcel(fileName);
		return sh.getRows();
	}

	public boolean verification(String typeId,String idnum) throws BiffException, IOException{
		ReadExcelFile ex = new ReadExcelFile();
		Sheet sh = ex.readExcel("C:/Users/1587930/workspace/Banking/src/GovIdentification.xls");
		typeId = typeId.toUpperCase();
		idnum = idnum.toUpperCase();
		int row = 0;
		int rcol=0;
		for(int col=0; col<sh.getColumns(); col++){
			String nc = sh.getCell(col,row).getContents();
			if(typeId.equals(nc)){
				rcol = col;
			}
		}
		int rrow = 0;
		for(row=1; row<sh.getRows(); row++){
			if(idnum.equals(sh.getCell(rcol,row).getContents())){
				rrow = row;
			}
		}
		
		String n = getAccountName().toUpperCase();
		String ph = getPhoneNumber().toUpperCase();
		String a = getAddress().toUpperCase();
		if(n.equals(sh.getCell(3,rrow).getContents()) && ph.equals(sh.getCell(4,rrow).getContents()) && a.equals(sh.getCell(5,rrow).getContents())){
			return true;
		}
		else{
			return false;
		}
	}
	
	public long issueAccountNumber(){
		long acno = (long)(Math.random() * (10e12-1) + 10e11);
		setAccountNumber(acno);
		return acno;
	}
	
}