 class Loan extends Account{
	
	public void HomeLoan( float amount, float balance){
		if(balance>=500000)
		 {
		   if(amount<=3000000)
			System.out.println("Eligible for home loan below 30lakhs");
		   else
			System.out.println("Not eligible for home loan");
		 }
		if(balance>=1500000)
		{
		   if(3000000<amount && amount < 7500000)
			System.out.println("Eligible for home loan between 30lakhs to 75laks");
		   else
			System.out.println("Not eligible for home loan");
	    }
		if(balance>=3500000)
		{
			if(amount>=7500000)
				System.out.println("Eligible for home loan of above 75lakhs");
			else
				System.out.println("Not eligible for loan");
		}
	}

	public void PersonalLoan(float balance){
		if(balance>=500000)
			System.out.println("Eligible for personal loan");
		else
			System.out.println("Not eligible for personal loan");
	}
	
	public void AutoLoan(float Salary){
		if(Salary>=300000)
			System.out.println("Eligible for AutoLoan");
		else
			System.out.println("Not eligible for AutoLoan");
	}

}
