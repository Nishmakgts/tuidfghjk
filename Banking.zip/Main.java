import java.util.*;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
//import java.lang.*;
import java.io.*;
import jxl.*;

enum TType{DEPOSIT, WITHDRAWL, TRANSFER, CLOSEACCOUNT, LOAN};//, REPORTS, MINISTATEMENTS};

public class Main{
	
	private static final CellType LABEL = null;

	public static void main(String[] args) throws BiffException, IOException, WriteException{
		Scanner sc = new Scanner(System.in);
		System.out.println("Existing Account Holder(Y/N):");
		char ex = sc.next().charAt(0);
		sc.nextLine();
		ex = Character.toUpperCase(ex);
		if(ex == 'Y'){
			System.out.println("Enter the UserName(a.k.a Name):");
			String un = sc.nextLine();
			System.out.println("Enter the password:");
			String pass = sc.nextLine();
			
			ReadExcelFile rex = new ReadExcelFile();
			Sheet sh = rex.readExcel("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls");
			
			un = un.toUpperCase();
			pass = pass.toUpperCase();
			
			int oprow=0,count=0;
			
			for(int row=1; row<sh.getRows(); row++ ){
				//System.out.println("password:"+sh.getCell(2,row).getContents());
				if(un.equals(sh.getCell(1,row).getContents())){
					//System.out.println("password:"+sh.getCell(5,row).getContents());
					if(pass.equals(sh.getCell(5,row).getContents())){
						oprow = row;
						count++;
						break;
					}
				}
			}
			if(count==0){
				System.out.println("Incorrect Password");
				System.exit(0);
			}
			
			System.out.println("MENU:");
			TType arr[] = TType.values();
			for(TType t :arr){
				System.out.println((t.ordinal()+1)+"."+t); 	
			}
			
			System.out.println("Enter your Choice:");
			int choice = sc.nextInt();
			sc.nextLine();
			
			Account acc = new Account();
			System.out.println(sh.getCell(4,oprow).getType());
			float s2f = Float.valueOf(sh.getCell(4,oprow).getContents());
			acc.setAccountBalance(s2f);
			
			WriteExcel wex = new WriteExcel();
			String f2s="",l2s="";
			CellType ct;
			switch(choice){
			case 1: System.out.println("Enter the amount to be deposited:");
					float dep = sc.nextFloat();
					sc.nextLine();
					acc.deposit(dep);
					f2s = String.format ("%,.2f",acc.getAccountBalance());
					ct = sh.getCell(4,oprow).getType();
					wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",4,oprow,f2s,ct);
					System.out.println("Your Account balance after deposit of Rs."+dep+" is Rs."+acc.getAccountBalance());
					break;
					
			case 2: System.out.println("Enter the amount to be withdrawn:");
					float w = sc.nextFloat();
					sc.nextLine();
					acc.withdrawl(w);
					f2s = String.format ("%,.2f",acc.getAccountBalance());
					ct = sh.getCell(4,oprow).getType();
					wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",4,oprow,f2s,ct);
					System.out.println("Your Account balance after withdrawl of Rs."+w+" is Rs."+acc.getAccountBalance());
					break;
					
			case 3: Account benAcc = new Account();
					System.out.println("Enter the Beneficiary Account Number:");
					long benAN = sc.nextLong();
					sc.nextLine();
					l2s = String.format("%l", benAN);
					
					int benrow=0,flag=0;
					for(int row=1; row<sh.getRows(); row++ ){
						if(l2s.equals(sh.getCell(0,row).getContents())){
							flag=1;
							break;
						}
					}
					
					while(flag==0){
						System.out.println("Invalid Account Number");
						System.out.println("Enter Valid Beneficiary Account Number:");
						benAN = sc.nextLong();
						sc.nextLine();
						l2s = String.format("%l", benAN);
						for(int row=1; row<sh.getRows(); row++ ){
							if(l2s.equals(sh.getCell(0,row).getContents())){
								flag=1;
								break;
							}
						}
					}
					
					for(int row=1; row<sh.getRows(); row++ ){
						if(l2s.equals(sh.getCell(0,row).getContents())){
							benrow = row;
							break;
						}
					}
					
					ct = sh.getCell(4,benrow).getType();
					s2f = Float.valueOf(sh.getCell(4,benrow).getContents());
					benAcc.setAccountBalance(s2f);
					
					System.out.println("Enter the amount to be transferred");
					float transferAmount = sc.nextFloat();
					sc.nextLine();
					
					acc.transfer(transferAmount, benAcc);
										
					f2s = String.format ("%,.2f",acc.getAccountBalance());
					wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",4,oprow,f2s,ct);
					
					f2s = String.format ("%,.2f",benAcc.getAccountBalance());
					wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",4,benrow,f2s,ct);

					System.out.println("Your Account Balance after Benificiary Account Transfer is Rs."+acc.getAccountBalance());
					break;
					
			case 4:	System.out.println("Closing your Account...");
					w = acc.getAccountBalance();
					acc.withdrawl(w);
					System.out.println("Account Balance of Rs."+w+" is withrawn");
					//sh.deleteRow(oprow);
					ct = sh.getCell(4,1).getType();
					for(int col=0; col<6; col++){
						wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",col,oprow,"",ct);
					}
					System.out.println("Your Account is CLOSED");
					break;
					
			case 5:	System.out.println("Enter the type of the loan(Personal/Home/Auto):");
					String loanType = sc.nextLine();
					loanType = loanType.toUpperCase();
					System.out.println("Enter the amount of loan:");
					float  loanAmount = sc.nextFloat();
					sc.nextLine();
					System.out.println("Enter the Account Number:");
					long an = sc.nextLong();
					sc.nextLine();
					
					acc = new Loan();
					acc.setAccountNumber(an);
					
					switch(loanType){
					case "PERSONAL": System.out.println("Account Balance:" + acc.getAccountBalance());
									 ((Loan)acc).PersonalLoan(acc.getAccountBalance());
									 break;
					case "HOME"    : System.out.println("Account Balance:" + acc.getAccountBalance());
					 				 ((Loan)acc).HomeLoan(loanAmount,acc.getAccountBalance());
					 				 break;
					case "AUTO"    : System.out.println("Enter your salary per annum:");
					 				 float sal = sc.nextFloat();
					 				 sc.nextLine();
					 				 ((Loan)acc).AutoLoan(sal);
					 				 break;
					default        : System.out.println("No Valid Type of Loan entered, exiting...");
									 break;
					}
					
			//case 6:
			//case 7:
				default: System.out.println("No Valid Choice is entered, exiting...");
						 break;
			}
		}
		else{
			System.out.println("Opening a new Account...");
			System.out.println("Enter your Name:");
			String name = sc.nextLine();
			System.out.println("Enter your Phone Number:");
			String ph = sc.nextLine();
			System.out.println("Enter your Address:");
			String add = sc.nextLine();
			boolean flag;
			String typeId;
			do{
				flag = true;
				System.out.println("Enter the type of Identification Number:");
				System.out.println("As shown in CAPS(PAN/AADHAR/DLICENCE):");
				typeId = sc.nextLine();
				if(!(typeId.equalsIgnoreCase("PAN")||typeId.equalsIgnoreCase("AADHAR")||typeId.equalsIgnoreCase("DLICENCE"))){
					System.out.println("Enter Valid Identification Type");
					flag = false;
				}
			}while(!flag);
			
			System.out.println("Enter the "+typeId+" Number:");
			String idnum = sc.nextLine();
			
			Account acc = new OpenAccount(name,ph,add,idnum);
			boolean b = ((OpenAccount)acc).verification(typeId,idnum);
			if(b){
				long acno = ((OpenAccount)acc).issueAccountNumber();
				acc.setAccountNumber(acno);
				System.out.println("Issued Account Number:"+acno);
				acc.setAccountBalance(-500);
				System.out.println("Amount of Rs.500 is deducted from the Account Balance for opening the account");
				System.out.println("Acknowledgement: Account OPENED");
				System.out.println("Set Password (min 8 characters):");
				acc.setPassword(sc.nextLine());
				
				String[] colValues = {Long.toString(acc.getAccountNumber()),acc.getAccountName(),acc.getPhoneNumber(),acc.getAddress(),Float.toString(acc.getAccountBalance()),acc.getPassword()};
				WriteExcel wex = new WriteExcel();
				//CellType ct = ((OpenAccount)acc)..getCell(4,1).getType();
				CellType ct = LABEL;
				int R = ((OpenAccount)acc).getSheetRows("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls");
				for(int col=0; col<colValues.length; col++){
					wex.write("C:/Users/1587930/workspace/Banking/src/AccountHolders.xls",col,R,colValues[col],ct);
				}
			}
			else{
				System.out.println("Enter Valid Address Proof Number");
				System.exit(0);
			}
		}
		sc.close();
	}
}